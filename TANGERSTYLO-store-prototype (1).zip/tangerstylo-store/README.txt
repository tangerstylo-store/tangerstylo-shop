TANGERSTYLO - Prototype v1

Included:
- index.html: responsive Arabic storefront (white/blue)
- starter product: رجال وذئاب, 50 DH
- cart with quantity controls and total
- WhatsApp order link to +212 777 499 449
- cash on delivery message
- simple local product manager (add/delete, import/export JSON)

Important limitations:
- This is a local prototype, not a published website.
- The product manager currently saves products only in the browser's local storage. Changes do not sync to other devices or a public website.
- Before launch, connect a GitHub repository to Cloudflare Pages, then set up a shared product CMS or a database-backed admin. Pages CMS edits files in a GitHub repository and can manage media; it requires a GitHub account and repository setup.

To preview:
1. Extract the ZIP.
2. Open index.html in Chrome or Edge.
3. Add a product using the "إدارة المنتجات" link at the bottom.
4. Try the cart and WhatsApp order button.

Hosting references:
Cloudflare Pages: https://developers.cloudflare.com/pages/get-started/git-integration/
Pages CMS quick start: https://pagescms.org/docs/quick-start/
